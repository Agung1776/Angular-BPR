import { CommonModule } from '@angular/common';
import { Component, inject, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { EmployeeService } from './employee.service';
import { Employee } from './employee';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';



@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, CommonModule, ReactiveFormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit{
  title = 'Angular';
  employeeForm!: FormGroup
  EmployeeService = inject(EmployeeService)
  Employee: Employee[] = [];
  
  constructor(private fb: FormBuilder){
    this.EmployeeService.getAllEmployee().subscribe({
      next: (data) => {
        this.Employee= data;
      },
      error: (err) => {
        console.log(err);
      }
      }) 
    this.EmployeeService.insertEmployee({}).subscribe({
      next: (data) => {
        console.log(data);
      },
      error: (err) => {
        console.log(err);
      }
    })
  }
  ngOnInit() {
    this.employeeForm = this.fb.group({
      FirstName: [''],
      LastName: [''],
      ID: [''],
      HireDate: [''],
      TerminationDate: [''],
      salary: ['']
    });
  }
  populateForm(employee: Employee) {
    this.employeeForm.patchValue({
      ID: employee.ID,
      FirstName: employee.FirstName,
      LastName: employee.LastName,
      HireDate: employee.HireDate,
      TerminationDate: employee.TerminationDate,
      salary: employee.Salary
    });
  }
  onUpdate() {
    if (this.employeeForm.valid) {
      this.EmployeeService.updateEmployee(this.employeeForm.value).subscribe({
        next: (data) => console.log('Employee updated successfully', data),
        error: (err) => console.error('Error updating employee', err)
      });
    }}
  onSubmit() {
    this.EmployeeService.insertEmployee(this.employeeForm.value).subscribe({
      next: (data) => console.log('Employee added successfully', data),
      error: (err) => console.error('Error adding employee', err)
    });
  }
  onDelete(ID: number) {
    this.EmployeeService.deleteEmployee(ID).subscribe({
      next: (data) => {
        this.Employee = this.Employee.filter(emp => emp.ID !== ID);
        console.log('Employee deleted successfully', data);
      },
      error: (err) => console.error('Error deleting employee', err)
    });
  }
}
