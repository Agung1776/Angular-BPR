export interface Employee {
    FirstName: string;
    LastName: string;
    ID: number;
    HireDate: Date;
    TerminationDate: Date;
    Salary:number;
}
