import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError, map } from 'rxjs/operators';
import { Employee } from './employee'
import { throwError } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor() { }
  private url = 'http://localhost:8000/employee'; 

  http = inject(HttpClient);
  

  getAllEmployee() {
    return this.http.get<{ user: Employee[] }>(this.url).pipe(
      map(response => response.user),
      catchError(this.handleError)
    );
  }

  private handleError(error:any){
    console.log(error);
    return throwError(() => new Error('Something bad happened. please try again later.'));
  }
  

  getEmployeeById(ID: number){
    return this.http.get(this.url+'/'+ID);
  }

  insertEmployee(employee: any){
    return this.http.post(this.url, employee);
  }

  updateEmployee(employee: any){
    return this.http.put(this.url, employee);
  }

  deleteEmployee(ID: number){
    return this.http.delete(this.url+'/'+ID);
  }
}
